export interface colorentity{
    code:string,
    name:string
}